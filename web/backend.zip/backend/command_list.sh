#!/bin/bash
. /etc/profile

compgen -c
